-- phpMyAdmin SQL Dump
-- version 3.3.2deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 21, 2011 at 06:47 PM
-- Server version: 5.1.41
-- PHP Version: 5.3.2-1ubuntu4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE IF NOT EXISTS `posts` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `body` text NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `title`, `body`, `created`, `modified`) VALUES
(1, 'First Post daw ni', 'More content for this awesome daw...', '2011-01-14 18:52:34', '2011-01-21 15:14:15'),
(2, 'Here''s the 2nd Post', 'hehe ^_^', '2011-01-14 18:53:14', '2011-01-15 18:39:08'),
(5, 'hahaha', 'huhuhu', '2011-01-15 20:33:25', '2011-01-15 20:33:25'),
(9, 'hi.. hehe', 'lady gaga - BAd romance :Pm :P :D hehe', '2011-01-17 18:55:24', '2011-01-17 18:55:24'),
(8, 'hi maui', 'hehe \r\n\r\nhehe\r\n\r\nhehe', '2011-01-17 18:49:12', '2011-01-17 18:49:12'),
(10, 'cakebake, pandesal, slice bread.. ', 'cakebake, pandesal, slice bread..', '2011-01-17 18:56:53', '2011-01-17 18:56:53');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `password` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `group_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `password`, `name`, `group_id`) VALUES
(2, 'admin@admin.com', '21232f297a57a5a743894a0e4a801fc3', 'Admin', 1),
(3, 'maui@maui.com', 'e98658ceafc428f7b35a484308fcfa21', 'Maureen', 1);
